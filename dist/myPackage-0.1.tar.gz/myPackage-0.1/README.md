#myPackage
This library is a result of a class example on how to create a python package.


#Requirements
The presence of a python  in a machine is necesary to run .py files.
There are python libraries that are necessary for the package to function.